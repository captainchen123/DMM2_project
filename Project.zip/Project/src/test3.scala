import java.io.{FileWriter, PrintWriter}
import java.time.{LocalDateTime, LocalTime}
import java.time.format.DateTimeFormatter

object test3 extends App {

  /* function to get current time as formatted string */
  def get_current_time(): String = {
    val current_time: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("M/d/yyyy H:mm")) // get current time and format
    current_time
  }


  println(get_current_time())



  val out = new FileWriter("DMMProjectData/ProjectData/HourlyProduction.csv", true)
  try {
    val i = get_current_time()+ "," + "0,0,0,0,0,0,0"
    out write(i.toString) // append a new line
  } finally {
    out.close()
  }

}
