// This is the implement of the concept of Strictness and Laziness
// Group 2
// Group Member:
// Annalina Wheeler
// Serhat Altay
// Chuanzhang Chen

object Implement extends App {

  // Implement the val and lazy val
  val condition = false

  val sampleVal: Unit = {
    println("Printing Val...")
  }

  lazy val lazyVal: Unit = {
    println("Printing lazyVal...")
  }

  if (condition) {
    println(sampleVal) // Printing Val...
    println(lazyVal)  // Nothing, A lazy val is not computed until it's needed, however condition is false
  }



  // Strictness and Laziness work with Function
  def printStrict(i:Int) = {
    println("Strictness")
    i+1
  }

  def printLazy(i: => Int) = {
    println("Laziness")
    i+1
  }

  val outputStrict = printStrict{
    println("print Strict")
    41}
  // output
  // print Strict
  // Strictness

  // This demonstrates one of the key benefits of lazy evaluation: it can avoid unnecessary computations.
  val outputLazy = printLazy{
    println("print Lazy")
    41
  }
  // output
  // Laziness
  // print Lazy



  // Implement Stream that generates Fibonacci numbers
  // In Scala, since Stream is a lazy collection, the Fibonacci sequence is not computed until it is required.
  // In this example, only the first 10 Fibonacci numbers are calculated when fibs.take(10).toList is called.

  val fibs: Stream[Int] = 0 #:: 1 #:: fibs.zip(fibs.tail).map { n => n._1 + n._2 }
  println(fibs.take(10).toList) // Prints the first 10 Fibonacci numbers: List(0, 1, 1, 2, 3, 5, 8, 13, 21, 34)




}
