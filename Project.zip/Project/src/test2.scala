import scala.io.StdIn
import scala.io.Source
import java.time.{LocalDateTime, LocalTime, YearMonth}
import java.time.temporal.WeekFields
import java.util.Locale
import java.time.format.DateTimeFormatter
import scala.io.AnsiColor._



object test2 extends App {
  /* function to get current time as formatted string */
  def get_current_time(): String = {
    val current_time: String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:00")) // get current time and format
    current_time
  }
  val dateFormatter1 = DateTimeFormatter.ofPattern("M/d/yyyy H:mm")

  /////////////////////


  /* function to format the time*/
  def date_formatter(rows: List[List[String]], choice: String) = {
    val dateFormatter = DateTimeFormatter.ofPattern("M/d/yyyy H:mm")

    choice match {
      case "1" => // minute
        rows.groupBy { row =>
          val timestamp = row(0).trim
          val hour = LocalDateTime.parse(timestamp, dateFormatter)
          hour.format(DateTimeFormatter.ofPattern("M/d/yyyy HH:00"))
        }
      case "2" | "3" | "4" => // daily, weekly, monthly
        val groupedRows = choice match {
          case "2" => // daily
            rows.groupBy { row =>
              val timestamp = row(0).trim
              val date = LocalDateTime.parse(timestamp, dateFormatter).toLocalDate
              date.format(DateTimeFormatter.ISO_LOCAL_DATE)
            }
          case "3" => // weekly
            rows.groupBy { row =>
              val timestamp = row(0).trim
              val date = LocalDateTime.parse(timestamp, dateFormatter).toLocalDate
              val weekFields = WeekFields.of(Locale.getDefault)
              val weekOfYear = date.get(weekFields.weekOfWeekBasedYear())
              s"${date.getYear}-W$weekOfYear"
            }
          case "4" => // monthly
            rows.groupBy { row =>
              val timestamp = row(0).trim
              val date = LocalDateTime.parse(timestamp, dateFormatter).toLocalDate
              val yearMonth = YearMonth.from(date)
              yearMonth.format(DateTimeFormatter.ofPattern("yyyy-MM"))
            }
        }
        groupedRows
    }
  }


  /* function to read contents of .csv file and returns list of contents */
  def read_file(filename: String): List[List[String]] = {
    val source = Source.fromFile(filename)
    var contents: List[List[String]] = List()
    try {
      val lines = source.getLines().toList.tail // ignore header line
      for (line <- lines) {
        val fields = line.split(",").map(_.trim).toList
        contents = contents :+ fields
      }
      contents // return a list of fields
    } catch {
      case e: Exception => List(List("error", "operation failed."))
    } finally {
      source.close()
    }
  }

  // prints the data in the file in a cooler way.
  def printTable(rows: List[List[String]], header: Option[List[String]] = None) = {
    // calculate the maximum width of each column
    val allRows = header.map(h => h :: rows).getOrElse(rows)
    val colWidths = allRows.transpose.map(col => col.map(cell => cell.length).max)
    // create a format string for each row
    val formatStr = colWidths.map(width => s"%-${width}s").mkString(" | ")
    // print the header if provided
    header.foreach { h =>
      println(formatStr.format(h: _*))
      println(colWidths.map("-" * _).mkString("-+-"))
    }
    // print the table rows
    for (row <- rows) {
      println(formatStr.format(row: _*))
    }
  }

  val rows = read_file("DMMProjectData/ProjectData/HourlyProduction.csv")
  println("Choose an option:\n1) Filter total consumption by hourly\n2) Filter total consumption by daily.\n3) Filter total consumption by weekly.\n4) Filter total consumption by monthly.")
  val user_choice_for_filter: String = StdIn.readLine() // get user input
  val groupedRows = date_formatter(rows, user_choice_for_filter)
  val dateFormatter = DateTimeFormatter.ofPattern("M/d/yyyy H:mm")





}
